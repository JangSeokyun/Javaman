package Jpackman;

public class Jpacman02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try       
		{          
			PacmanGame Pg = new PacmanGame();       
		}       
		catch(Exception e)
		{          
			System.out.println("실행에 오류가 발생했습니다" + e);
		}    
	}

}